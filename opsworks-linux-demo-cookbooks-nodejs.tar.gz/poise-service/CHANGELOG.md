# Changelog

## v1.0.2
* Fix a potential infinite loop when starting a service with the dummy provider.
* [#2](https://github.com/poise/poise-service/pull/2) Remove usage of root
  default files so uploading with Berkshelf works (for now).

## v1.0.1

* Don't use a shared, mutable default value for `#environment`.

## v1.0.0

* Initial release!
